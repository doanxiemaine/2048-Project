/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg2048;

/**
 *
 * @author trufmgajtgiof
 */
public class GameStack {
   
    private int maxSize;
    private int top;
    private Object[] arr;
    
    //constructor
    public GameStack(int size){
        maxSize = size;
        arr = new Object[maxSize];
        top = -1;
    }
    
    //push method
    public void push(Object in){
        arr[++top] = in;
    }
    
    //pop method
    public Object pop(){
        return arr[top--];
    }
    
    //peek method
    public Object peek(){
        return arr[top];
    }
    
    //isEmpty method
    public boolean isEmpty(){
        return (top == -1);
    }
    
    //isFull method
    public boolean isFull(){
        return (top == maxSize-1);
    }
    
    //size of stack
    public int size(){
        return top+1;
    }
    
}
