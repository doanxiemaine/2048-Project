/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg2048;


import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.image.BufferedImage;
import javax.swing.JPanel;

/**
 *
 * @author hvtrung
 */
public class Game extends JPanel implements KeyListener,MouseListener,MouseMotionListener, Runnable {

    private static final long serialVersionUID = 1L;
    public static final int WIDTH = 900;
    public static final int LENGTH = 900;
    private boolean running;
    static final Font main = new Font("Bebas Neue Regular", Font.PLAIN, 28);

    private Thread game;
    private BufferedImage Image = new BufferedImage(WIDTH, LENGTH, BufferedImage.TYPE_INT_RGB);
    private Screen screen;
    
    
    public Game() {
        setFocusable(true);
        setPreferredSize(new Dimension(WIDTH, LENGTH));
        addKeyListener(this);
        addMouseListener(this);
        addMouseMotionListener(this);
        
        screen= Screen.getInstance();
        screen.add("Menu", new MainMenuPanel());
        screen.add("Play",  new PlayPanel());
        screen.add("Play 5x5",  new PlayPanel5by5());
        screen.add("Play 6x6",  new PlayPanel6by6());
        screen.add("Leaderboards", new LeaderboardsPanel());
        screen.setCurrentPanel("Menu"); 
        
    }

    private void update() {
        screen.update();
        keyboard.update();

    }

    private void render() {
        Graphics2D g = (Graphics2D) Image.getGraphics();
        g.setColor(Color.white);
        g.fillRect(0, 0, WIDTH, LENGTH);
        screen.render(g);
        g.dispose();

        Graphics2D g2d = (Graphics2D) getGraphics();
        g2d.drawImage(Image, 0, 0, null);
        g2d.dispose();

    }

    @Override
    public void run() {
        int fps = 0;
        int update = 0;
        long fpsTimer = System.currentTimeMillis();
        double nsPerUpdate = 300000000.0 / 60;
        //last update time in nanaseconds
        double then = System.nanoTime();
        double unprocessed = 0;
        while (running) {
            boolean shouldRender = false;
            double now = System.nanoTime();
            unprocessed += (now - then) / nsPerUpdate;
            then = now;
            //update queue
            while (unprocessed >= 1) {
                update++;
                update();
                unprocessed--;
                shouldRender = true;
            }
            // render
            if (shouldRender) {
                fps++;
                render();
                shouldRender = false;
            } else {
                try {
                    Thread.sleep(1);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
        //FPS Timer
        if (System.currentTimeMillis() - fpsTimer > 1000) {
            System.out.printf("%d fps %d updates", fps, update);
            System.out.println("");
            fps = 0;
            update = 0;
            fpsTimer += 1000;

        }
    }

    public synchronized void start() {
        if (running) {
            return;
        }
        running = true;
        game = new Thread(this, "game");
        game.start();
    }

    public synchronized void stop() {
        if (!running) {
            return;
        }
        running = false;
        System.exit(0);
    }

    @Override
    public void keyTyped(KeyEvent e) {

    }

    @Override
    public void keyPressed(KeyEvent e) {
        keyboard.keyPressed(e);
    }

    @Override
    public void keyReleased(KeyEvent e) {
        keyboard.keyReleased(e);
    }

    @Override
    public void mouseClicked(MouseEvent e) {
    }

    @Override
    public void mousePressed(MouseEvent e) {
        screen.mousePressed(e);
    }

    @Override
    public void mouseReleased(MouseEvent e) {
        screen.mouseReleased(e); 
    }

    @Override
    public void mouseEntered(MouseEvent e) {
    }

    @Override
    public void mouseExited(MouseEvent e) {
    }

    @Override
    public void mouseDragged(MouseEvent e) {
        screen.mouseDragged(e);
    }

    @Override
    public void mouseMoved(MouseEvent e) {
        screen.mouseMoved(e);
    }

}
