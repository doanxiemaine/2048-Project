/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg2048;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import javax.imageio.ImageIO;

/**
 *
 * @author trufmgajtgiof
 */
public class PlayPanel6by6 extends Panel{
    private GameBoard6by6 board;
    private BufferedImage info;
    private ScoreManager6by6 scores;
    private Font scoreFont;
    
    private Button playAgain;
    private Button mainMenu;
    private Button screenShot;
    
    private int smallButtonW = 160;
    private int spacing = 20;
    private int bigButtonW = smallButtonW * 2 + spacing;
    private int buttonLength = 50;
    private boolean added;
    private int a=0;
    private Font gOverF;
    private boolean screenshot;

    public PlayPanel6by6() {
        scoreFont = Game.main.deriveFont(25f);
        gOverF = Game.main.deriveFont(60f);
        board = new GameBoard6by6(Game.WIDTH / 2 - GameBoard.BOARD_WIDTH / 2 - 100, Game.LENGTH  - GameBoard.BOARD_LENGTH - 300 ); // - 20
        scores = board.getScores();
        info = new BufferedImage(Game.WIDTH, 200, BufferedImage.TYPE_INT_RGB);

        mainMenu = new Button(Game.WIDTH / 2 - bigButtonW / 2, 450, bigButtonW, buttonLength);
        playAgain = new Button(mainMenu.getX(), mainMenu.getY() - spacing - buttonLength, smallButtonW, buttonLength);
        screenShot = new Button(playAgain.getX() + playAgain.getWidth() + spacing, playAgain.getX(), smallButtonW, buttonLength);

        playAgain.setText("Play Again");
        screenShot.setText("Screenshot");
        mainMenu.setText("Back To Main Menu");

        playAgain.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent e) {
                board = new GameBoard6by6(Game.WIDTH / 2 - GameBoard.BOARD_WIDTH / 2, Game.LENGTH  - GameBoard.BOARD_LENGTH - 150 ); // - 20
                scores = board.getScores();                
                a = 0;

                remove(playAgain);
                remove(screenShot);
                remove(mainMenu);

                added = false;

            }
        });

        screenShot.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                screenshot = true;
            }

        });

        mainMenu.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                Screen.getInstance().setCurrentPanel("Menu");

            }

        });
    }

    public void display(Graphics2D g) {
        Graphics2D g2d = (Graphics2D) info.getGraphics();
        g2d.setColor(Color.white);
        g2d.fillRect(0, 0, info.getWidth(), info.getHeight());
        g2d.setColor(Color.CYAN);
        g2d.setFont(scoreFont);
        g2d.drawString("" + scores.getCurrentScore(), 30, 40);
        g2d.setColor(Color.red);
        g2d.drawString("Best: " + scores.getCurrentHighScore(), Game.WIDTH - DrawUtils.getMessageWidth("Best: " + scores.getCurrentHighScore(), scoreFont, g2d) - 20, 40);
        g2d.dispose();
        g.drawImage(info,0,0,null);
    }
    
    public void displayGameOver(Graphics2D g){
        g.setColor(new Color(222,222,222,a));
        g.fillRect(0, 0, Game.WIDTH, Game.LENGTH);
        g.setColor(Color.PINK);
        g.drawString("Game Over! ",Game.WIDTH/2 - DrawUtils.getMessageWidth("Game Over!", gOverF, g)/2,250);
    }
    @Override
    public void update(){
        board.update();
        if(board.isLost()){
            a++;
            if(a > 170) 
                a = 170;
            
        }
    }
    @Override
    public void render(Graphics2D g){
        display(g);
        board.render(g);
        if(screenshot){
            BufferedImage bl = new BufferedImage(Game.WIDTH, Game.LENGTH, BufferedImage.TYPE_INT_RGB);
            Graphics2D g2d = (Graphics2D) bl.getGraphics();
            g2d.setColor(Color.white);
            g2d.fillRect(0, 0, Game.WIDTH, Game.LENGTH);
            display(g2d);
            board.render(g2d);
            try{
                ImageIO.write(bl, "gif", new File(System.clearProperty("user.home") + "\\Desktop", "screenshot" + System.nanoTime() + ".giif")  );
                
            } catch(Exception e){
                e.printStackTrace();
            }
            screenshot = false;
        }
        if(board.isLost()){
            if(!added){
                added = true;
                add(mainMenu);
                add(screenShot);
                add(playAgain);
            }
            displayGameOver(g);
        }
        super.render(g);
    }
}
