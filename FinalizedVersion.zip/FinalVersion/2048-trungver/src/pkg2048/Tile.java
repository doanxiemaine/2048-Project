/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg2048;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.geom.AffineTransform;
import java.awt.image.BufferedImage;

/**
 *
 * @author hvtrung
 */
public class Tile {
    public static final int WIDTH = 80;
    public static final int LENGTH = 80;
    public static final int SLIDE_SPEED = 20;
    public static final int ARC_WIDTH =15;
    public static final int ARC_LENGTH = 15;
    
    private int value;
    private BufferedImage tileImage;
    private Color background;
    private Color text;
    private Font font;
    private int x;
    private int y;
    private Point nextPosition; 
    private boolean canCombine = true;
    //Animation of Tile beginning
    private boolean startAnimation = true;
    private double scaleFirst = 0.1;
    private BufferedImage startImage;
    //Animation of Tile each time combine together
    private boolean combineAnimation = false;
    private double scaleCombine = 1.3;
    private BufferedImage combineImage;
    
    public Tile(int value, int x, int y){
        this.value = value;
        this.x = x;
        this.y = y;
        nextPosition = new Point(x,y);
        tileImage = new BufferedImage(WIDTH,LENGTH,BufferedImage.TYPE_INT_ARGB);
        startImage = new BufferedImage(WIDTH,LENGTH,BufferedImage.TYPE_INT_ARGB);
        combineImage = new BufferedImage(WIDTH * 2,LENGTH * 2 ,BufferedImage.TYPE_INT_ARGB);
        drawImage();
    }
    private void drawImage(){
        Graphics2D g = (Graphics2D)tileImage.getGraphics();
        // Color(....) => 0x code of number in hexadecimal: 
        // can use hexacode to setColor
        if(value == 2){
            background = new Color(0xeee4da);//background is gray
            text  = new Color(0x000000); // text is black
         }
        else if(value == 4){
            background = new Color(0xede0c8);
            text = new Color(0xffffff); // text is white
            
            
        }
         else if(value == 8){
            background = new Color(0xf2b179);
            text = new Color(0xffffff); 
            
            
        }
         else if(value == 16){
            background = new Color(0xf59563);
            text = new Color(0xffffff);
            
            
        }
         else if(value == 32){
            background = new Color(0xf67c5f);
            text = new Color(0xffffff);
            
            
        }
         else if(value == 64){
            background = new Color(0xf65e3b);
            text = new Color(0xffffff);
            
            
        }
         else if(value == 128){
            background = new Color(0xedcf72);
            text = new Color(0xffffff);
            
            
        }
         else if(value == 256){
            background = new Color(0xedcc61);
            text = new Color(0xffffff);
            
            
        }
         else if(value == 512){
            background = new Color(0xedc850);
            text = new Color(0xffffff);
            
            
        }
         else if(value == 1024){
            background = new Color(0xedc53f);
            text = new Color(0xffffff);
            
            
        }
         else if(value == 2048){
            background = new Color(0xedc22e);
            text = new Color(0xffffff);
            
            
        }
         else{
             background = Color.GREEN;
             text = Color.WHITE;
         }
        g.setColor(new Color(0,0,0,0));
        g.fillRect(0, 0, WIDTH, LENGTH);
        
        g.setColor(background);
        g.fillRoundRect(0, 0, WIDTH, LENGTH, ARC_WIDTH, ARC_LENGTH);
        g.setColor(text);
        if(value <= 64){
            font = Game.main.deriveFont(36f);
        }
        else{
            font = Game.main;
        }
        g.setFont(font);
        //Initiallize the message of Titile in the middle of box
        //get the center and then move to the left half of the message
        int drawX = WIDTH /2 - DrawUtils.getMessageWidth("" + value, font, g)/2;  
        //get the y-coordinate (bottom left)
        int drawY = LENGTH/2 + DrawUtils.getMessageLength("" + value, font, g)/2;
        g.drawString("" + value , drawX, drawY);
        g.dispose();
        
    }
    public void setValue(int value){
        this.value = value;
        drawImage();
    }
    public int getValue(){
        return value;
    }
    public void update()
    {
        if(startAnimation)
        {
            AffineTransform transform = new AffineTransform();
            transform.translate(WIDTH/2 - scaleFirst *  WIDTH/2, LENGTH/2 - scaleFirst * LENGTH/2);
            transform.scale(scaleFirst, scaleFirst);
            Graphics2D g2d = (Graphics2D) startImage.getGraphics();
            g2d.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BICUBIC);
            g2d.setColor(new Color(0,0,0,0));
            g2d.fillRect(0, 0, WIDTH, LENGTH);
            g2d.drawImage(tileImage, transform, null);
            scaleFirst += 0.1;
            g2d.dispose();
            if(scaleFirst >= 1)
                startAnimation = false;
            
        } 
        else if(combineAnimation){
            
            AffineTransform transform = new AffineTransform();
            transform.translate(WIDTH/2 - scaleCombine *  WIDTH/2, LENGTH/2 - scaleCombine * LENGTH/2);
            transform.scale(scaleCombine, scaleCombine);
            Graphics2D g2d = (Graphics2D) combineImage.getGraphics();
            g2d.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BICUBIC);
            g2d.setColor(new Color(0,0,0,0));
            g2d.fillRect(0, 0, WIDTH, LENGTH);
            g2d.drawImage(tileImage, transform, null);
            scaleCombine -= 0.05;
            g2d.dispose();
            if(scaleCombine <= 1)
                combineAnimation = false;
            
        }
        
    }
    public void render(Graphics2D g)
    {
        if(startAnimation){
            g.drawImage(startImage, x, y,null);
        }
        else if(combineAnimation){
            g.drawImage(combineImage, (int) (x + WIDTH/2 - scaleCombine * WIDTH/2), (int) (y + LENGTH/2 - scaleCombine * LENGTH/2) ,null);
        }
        else{
            g.drawImage(tileImage, x, y, null);
        }
        
    }
    
    
    public boolean canCombine(){
        return canCombine;
    }
    public void setCanCombine(boolean canCombine){
        this.canCombine = canCombine;
    }
    public Point nextPosition(){
        return nextPosition;
    }
    public void setNextPosition(Point nextPosition){
        this.nextPosition = nextPosition;
    }
    
    public void setX(int x){
        this.x = x;
    }

    public int getX() {
        return x;
    }
    public void setY(int y){
        this.y = y;
    }

    public int getY() {
        return y;
    }
    
    public boolean isCombineAnimation(){
        return combineAnimation;
    }
    public void setCombineAnimation(boolean combineAnimation){
        this.combineAnimation = combineAnimation;
        if(combineAnimation)
            scaleCombine = 1.3;
    }
    
}
