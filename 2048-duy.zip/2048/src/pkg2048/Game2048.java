/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg2048;
import java.util.ArrayList;
import java.util.Random;
/**
 *
 * @author trufmgajtgiof
 */
public class Game2048{
    private Random r = new Random();
    private int[][] board;    
    public boolean lose = false;
    public boolean win = false;
    public int score = 0;
    private int highestScore = 0;
    public void setHighestScore(int s){
        highestScore = s;
    }
    
    //constructor
    public Game2048(){
        newGame();
        while(!isFull()){
            addTile();
            System.out.println("");
            display();
        }
    }
    
    //newGame method
    public void newGame(){
        score = 0;
        lose = false;
        win = false;
        board = new int[4][4];
        for (int i=0; i<4; i++)
            for (int j=0; j<4; j++)
                board[i][j] = 0;
        addTile();
        display();
    }
    
    //display method
    public void display(){
        for (int i=0; i<4; i++){
            for (int j=0; j<4; j++)
                System.out.print(""+board[i][j]+"\t");
            System.out.print("\n");
        }
    }
    
    //add at a random empty space
    public void addTile(){
        int choice = r.nextInt(16);
        while(!isEmpty(choice)){
            choice = r.nextInt(16);
        }
        int row = choice /4;
        int column = choice %4; 
            board[row][column] = 2;
    }
    
    //check if empty
    public boolean isEmpty(int position){
        int row = position / 4;
        int column = position % 4;
        if (board[row][column] == 0){
            return true;
        }
        else
            return false;
    }
    
    //check if there's no empty place left
    public boolean isFull(){
        int check = 0;
        for(int row = 0; row<4; row++){
            int column = 0;
            while (column <4){
                int position = column + row*4;
                if(isEmpty(position))
                    check++;
                column++;
            }
        }
        return (check == 0);
    }
    
    //main
    public static void main(String[] args){
        Game2048 g1 = new Game2048();
    }
}
