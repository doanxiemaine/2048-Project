/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg2048;

import java.util.Random;

/**
 *
 * @author trufmgajtgiof
 */
public class Game2048{
    
    //game function attributes
    private Random r = new Random(); //random generator 
    private int[][] board; //create the array to store tile's value
    public boolean lose = false;
    public boolean win = false;
    public int score = 0; //current score
    private int highestScore = 0; //highest score
    public int flag;
    //setHighestScore of the game
    public void setHighestScore(int s) {
        highestScore = s;
    }
    //getHighestScore of the game
    public int getHighestScore(){
        return highestScore;
    }
    
    //newGame method
    public void newGame() {
        score = 0;
        lose = false;
        win = false;
        board = new int[4][4];
        for (int i = 0; i < 4; i++) {
            for (int j = 0; j < 4; j++) {
                board[i][j] = 0;
            }
        }
        addTile();
        addTile();
    }

    //display method
    public int display(int row, int column) {
        return board[row][column];
    }

    //add at a random empty space
    public void addTile() {
        int choice = r.nextInt(16);
        while (!isEmpty(choice)) {
            choice = r.nextInt(16);
        }
        int row = choice / 4;
        int column = choice % 4;
        board[row][column] = 2;
    }

    //check if empty
    public boolean isEmpty(int position) {
        int row = position / 4;
        int column = position % 4;
        return board[row][column] == 0;
    }

    //check if there's no empty place left
    public boolean isFull() {
        int check = 0;
        for (int row = 0; row < 4; row++) {
            int column = 0;
            while (column < 4) {
                int position = column + row * 4;
                if (isEmpty(position)) {
                    check++;
                }
                column++;
            }
        }
        return (check == 0);
    }

    //moveLeft method
    public void moveLeft() {
        int tempValue;
        boolean movable = false;
        for (int startRow = 0; startRow < 4; startRow++) {
            int emptyCount = 1;
            for (int startColumn = 1; startColumn < 4; startColumn++) {
                int currentPosition = startRow * 4 + startColumn;
                int previousPosition = currentPosition - 1;
                if (!isEmpty(currentPosition)) {
                    if (isEmpty(previousPosition)) {
                        tempValue = board[startRow][startColumn];
                        board[startRow][startColumn] = board[startRow][startColumn - emptyCount];
                        board[startRow][startColumn - emptyCount] = tempValue;
                        int currentColumn = startColumn - emptyCount;
                        int destinationColumn = currentColumn - 1;
                        if (addUpTile(startRow, currentColumn, startRow, destinationColumn))
                            emptyCount++;
                        movable = true;
                    }
                    else{
                        int destinationColumn = startColumn - 1;
                        if (addUpTile(startRow, startColumn, startRow, destinationColumn))
                            movable = true;
                    }
                } else {
                    if (isEmpty(previousPosition))
                        emptyCount++;
                }
            }
        }
        if(movable)
            addTile();
        flag = 0;
    }

    //moveRight method
    public void moveRight() {
        int tempValue = 0;
        boolean movable = false;
        for (int startRow = 0; startRow < 4; startRow++) {
            int emptyCount = 1;
            for (int startColumn = 2; startColumn >= 0; startColumn--) {
                int currentPosition = startRow * 4 + startColumn;
                int previousPosition = currentPosition + 1;
                if (!isEmpty(currentPosition)) {
                    if (isEmpty(previousPosition)) {
                        tempValue = board[startRow][startColumn];
                        board[startRow][startColumn] = board[startRow][startColumn+emptyCount];
                        board[startRow][startColumn+emptyCount] = tempValue;
                        int currentColumn = startColumn + emptyCount;
                        int destinationColumn = currentColumn + 1;
                        if (addUpTile(startRow, currentColumn, startRow, destinationColumn))
                            emptyCount++;
                        movable = true;
                    }
                    else{
                        int destinationColumn = startColumn + 1;
                        if (addUpTile(startRow, startColumn, startRow, destinationColumn))
                            movable = true;
                    }
                } else {
                    if (isEmpty(previousPosition))
                        emptyCount++;
                }
            }
        }
        if(movable)
            addTile();
        flag = 0;
    }

    //move up method
    public void moveUp() {
        int tempValue = 0;
        boolean movable = false;
        for (int startColumn = 0; startColumn < 4; startColumn++) {
            int emptyCount = 1;
            for (int startRow = 1; startRow < 4; startRow++) {
                int currentPosition = startRow * 4 + startColumn;
                int previousPosition = (startRow - 1) * 4 + startColumn;
                if (!isEmpty(currentPosition)) {
                    if (isEmpty(previousPosition)) {
                        tempValue = board[startRow][startColumn];
                        board[startRow][startColumn] = board[startRow - emptyCount][startColumn];
                        board[startRow - emptyCount][startColumn] = tempValue;
                        int currentRow = startRow - emptyCount;
                        int destinationRow = currentRow - 1;
                        if (addUpTile(currentRow, startColumn, destinationRow, startColumn))
                            emptyCount++;
                        movable = true;
                    }
                    else{
                        int destinationRow = startRow - 1;
                        if(addUpTile(startRow, startColumn, destinationRow, startColumn))
                            movable = true;
                    }
                } else {
                    if (isEmpty(previousPosition))
                        emptyCount++;
                }
            }
        }
        if (movable)
            addTile();
        flag = 0;
    }

    //move down method
    public void moveDown() {
        int tempValue = 0;
        boolean movable = false;
        for (int startColumn = 0; startColumn < 4; startColumn++) {
            int emptyCount = 1;
            for (int startRow = 2; startRow >= 0; startRow--) {
                int currentPosition = startRow * 4 + startColumn;
                int previousPosition = (startRow + 1) * 4 + startColumn;
                if (!isEmpty(currentPosition)) {
                    if (isEmpty(previousPosition)) {
                        tempValue = board[startRow][startColumn];
                        board[startRow][startColumn] = board[startRow+emptyCount][startColumn];
                        board[startRow+emptyCount][startColumn] = tempValue;
                        int currentRow = startRow + emptyCount;
                        int destinationRow = currentRow + 1;
                        if (addUpTile(currentRow, startColumn, destinationRow, startColumn))
                            emptyCount++;
                        movable = true;
                    }
                    else{
                        int destinationRow = startRow + 1;
                        if(addUpTile(startRow, startColumn, destinationRow, startColumn))
                            movable = true;
                    }
                } else {
                    if (isEmpty(previousPosition))
                        emptyCount++;
                }
            }
        }
        if(movable)
            addTile();
        flag = 0;
    }
    
    //compare if two tiles have the same value
    public boolean addUpTile(int currentRow, int currentColumn, int destinationRow, int destinationColumn){
        int destinationPosition = destinationRow*4 + destinationColumn;
        if (destinationRow>-1 && destinationRow <4 && destinationColumn>-1 && destinationColumn <4){
            if (board[currentRow][currentColumn] == board[destinationRow][destinationColumn]){
                if (destinationPosition != flag){
                    board[destinationRow][destinationColumn] *= 2;
                    board[currentRow][currentColumn] = 0;
                    score += board[destinationRow][destinationColumn];
                    flag = destinationPosition;
                    return true;
                }
                else
                    return false;
            }
            else
                return false;
        }
        else
            return false;
    }
}