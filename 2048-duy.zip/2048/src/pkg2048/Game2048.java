/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg2048;

import java.util.ArrayList;
import java.util.Random;

/**
 *
 * @author trufmgajtgiof
 */
public class Game2048 {

    private Random r = new Random();
    private int[][] board;
    public boolean lose = false;
    public boolean win = false;
    public int score = 0;
    private int highestScore = 0;

    public void setHighestScore(int s) {
        highestScore = s;
    }

    //constructor
    public Game2048() {
        newGame();
        if (isFull()) {
            lose = true;
        }
        display();
        moveLeft();
        display();
        moveRight();
        display();
        moveUp();
        display();
        moveDown();
        display();
    }

    //newGame method
    public void newGame() {
        score = 0;
        lose = false;
        win = false;
        board = new int[4][4];
        for (int i = 0; i < 4; i++) {
            for (int j = 0; j < 4; j++) {
                board[i][j] = 0;
            }
        }
        addTile();
    }

    //display method
    public void display() {
        for (int i = 0; i < 4; i++) {
            for (int j = 0; j < 4; j++) {
                System.out.print("" + board[i][j] + "\t");
            }
            System.out.print("\n");
        }
        System.out.println("");
    }

    //add at a random empty space
    public void addTile() {
        int choice = r.nextInt(16);
        while (!isEmpty(choice)) {
            choice = r.nextInt(16);
        }
        int row = choice / 4;
        int column = choice % 4;
        board[row][column] = 2;
    }

    //check if empty
    public boolean isEmpty(int position) {
        int row = position / 4;
        int column = position % 4;
        if (board[row][column] == 0) {
            return true;
        } else {
            return false;
        }
    }

    //check if there's no empty place left
    public boolean isFull() {
        int check = 0;
        for (int row = 0; row < 4; row++) {
            int column = 0;
            while (column < 4) {
                int position = column + row * 4;
                if (isEmpty(position)) {
                    check++;
                }
                column++;
            }
        }
        return (check == 0);
    }

    //moveLeft method
    public void moveLeft() {
        int tempValue = 0;
        for (int startRow = 0; startRow < 4; startRow++) {
            int emptyCount = 0;
            for (int startColumn = 1; startColumn < 4; startColumn++) {
                int currentPosition = startRow * 4 + startColumn;
                int previousPosition = currentPosition - 1;
                if (!isEmpty(currentPosition)) {
                    if (isEmpty(previousPosition)) {
                        tempValue = board[startRow][startColumn];
                        board[startRow][startColumn] = board[startRow][startColumn - emptyCount];
                        board[startRow][startColumn - emptyCount] = tempValue;
                    }
                } else {
                    if (emptyCount == 0) {
                        emptyCount = 1;
                    }
                    emptyCount++;
                }
            }
        }
        addTile();
    }

    //moveRight method
    public void moveRight() {
        int tempValue = 0;
        for (int startRow = 0; startRow < 4; startRow++) {
            int emptyCount = 0;
            for (int startColumn = 2; startColumn >= 0; startColumn--) {
                int currentPosition = startRow * 4 + startColumn;
                int previousPosition = currentPosition + 1;
                if (!isEmpty(currentPosition)) {
                    if (isEmpty(previousPosition)) {
                        tempValue = board[startRow][startColumn + emptyCount];
                        board[startRow][startColumn + emptyCount] = board[startRow][startColumn];
                        board[startRow][startColumn] = tempValue;
                    }
                } else {
                    if (emptyCount == 0) {
                        emptyCount = 1;
                    }
                    emptyCount++;
                }
            }
        }
        addTile();
    }

    //move up method
    public void moveUp() {
        int tempValue = 0;
        for (int startColumn = 0; startColumn < 4; startColumn++) {
            int emptyCount = 1;
            for (int startRow = 1; startRow < 4; startRow++) {
                int currentPosition = startRow * 4 + startColumn;
                int previousPosition = (startRow - 1) * 4 + startColumn;
                if (!isEmpty(currentPosition)) {
                    if (isEmpty(previousPosition)) {
                        tempValue = board[startRow][startColumn];
                        board[startRow][startColumn] = board[startRow - emptyCount][startColumn];
                        board[startRow - emptyCount][startColumn] = tempValue;
                    }
                } else {
                    if (emptyCount == 0) {
                        emptyCount = 1;
                    }
                    emptyCount++;
                }
            }
        }
        addTile();
    }

    //move down method
    public void moveDown() {
        int tempValue = 0;
        for (int startColumn = 0; startColumn < 4; startColumn++) {
            int emptyCount = 1;
            for (int startRow = 2; startRow >= 0; startRow--) {
                int currentPosition = startRow * 4 + startColumn;
                int previousPosition = (startRow - 1) * 4 + startColumn;
                if (!isEmpty(currentPosition)) {
                    if (isEmpty(previousPosition)) {
                        tempValue = board[startRow - emptyCount][startColumn];
                        board[startRow - emptyCount][startColumn] = board[startRow][startColumn];
                        board[startRow][startColumn] = tempValue;
                    }
                } else {
                    if (emptyCount == 0) {
                        emptyCount = 1;
                    }
                    emptyCount++;
                }
            }
        }
        addTile();
    }

    //main
    public static void main(String[] args) {
        Game2048 g1 = new Game2048();
    }
}
