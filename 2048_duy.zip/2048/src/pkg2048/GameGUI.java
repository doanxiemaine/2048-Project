/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg2048;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import javax.swing.JPanel;

/**
 *
 * @author trufmgajtgiof
 */
public class GameGUI extends JPanel{
    private static final Color backgroundColor = new Color(0xbbada0); //add color of background
    private static final String fontName = "Arial"; //use font Arial
    private static final int tileSize = 64; //set size of the tile
    private static final int tilesMargin = 16;
    Game2048 game = new Game2048();
    
        //constructor
    public GameGUI() {
        setPreferredSize(new Dimension(340, 400)); //set dimension of the game 
        setFocusable(true);
        addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_ESCAPE) {
                    game.newNormalGame();
                }
                if (!game.win && !game.lose) {
                    switch (e.getKeyCode()) {
                        case KeyEvent.VK_LEFT:
                            game.moveLeft();
                            break;
                        case KeyEvent.VK_RIGHT:
                            game.moveRight();
                            break;
                        case KeyEvent.VK_DOWN:
                            game.moveDown();
                            break;
                        case KeyEvent.VK_UP:
                            game.moveUp();
                            break;
                        }
                    }
                if (!game.win && game.isFull()) {
                    if (!game.canMoveDown() && !game.canMoveLeft() && !game.canMoveRight() && !game.canMoveUp())
                        game.lose = true;                    
                }
                repaint();
            }
        }
        );
        game.newNormalGame();
    }
    
    @Override
    public void paint(Graphics g) {        
        super.paint(g);
        g.setColor(backgroundColor);
        g.fillRect(0, 0, this.getSize().width, this.getSize().height);
        for (int y = 0; y < 4; y++) {
            for (int x = 0; x < 4; x++) {
                drawTile(g, game.display(y, x), x, y);
            }
        }
    }
    
    public void drawTile(Graphics g2, int value, int x, int y) {
        Graphics2D g = ((Graphics2D) g2);
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g.setRenderingHint(RenderingHints.KEY_STROKE_CONTROL, RenderingHints.VALUE_STROKE_NORMALIZE);
        int xOffset = offsetCoors(x);
        int yOffset = offsetCoors(y);
        g.setColor(getBackground(value));
        g.fillRoundRect(xOffset, yOffset, tileSize, tileSize, 14, 14);
        g.setColor(getForeground(value));
        final int size = value < 100 ? 36 : value < 1000 ? 32 : 24;
        final Font font = new Font(fontName, Font.BOLD, size);
        g.setFont(font);

        String s = String.valueOf(value);
        final FontMetrics fm = getFontMetrics(font);

        final int w = fm.stringWidth(s);
        final int h = -(int) fm.getLineMetrics(s, g).getBaselineOffsets()[2];

        if (value != 0)
        g.drawString(s, xOffset + (tileSize - w) / 2, yOffset + tileSize - (tileSize - h) / 2 - 2);

        if (game.win || game.lose) {
            g.setColor(new Color(255, 255, 255, 30));
            g.fillRect(0, 0, getWidth(), getHeight());
            g.setColor(new Color(78, 139, 202));
            g.setFont(new Font(fontName, Font.BOLD, 48));
            if (game.win) {
                g.drawString("You won!", 68, 150);
            }
            if (game.lose) {
                g.drawString("Game over!", 50, 130);
                g.drawString("You lose!", 64, 200);                
            }
            if (game.win || game.lose) {
                g.setFont(new Font(fontName, Font.PLAIN, 16));
                g.setColor(new Color(128, 128, 128, 128));
                g.drawString("Press ESC to play again", 80, getHeight() - 40);
                if(game.getHighestScore() < game.score){
                    game.setHighestScore(game.score);
                }
            }
        }
        g.setFont(new Font(fontName, Font.PLAIN, 18));
        g.drawString("Score: \n" + game.score, 100, 365);
        g.drawString("Highest score: \n" +game.getHighestScore(), 220, 365);
    }
    
    private static int offsetCoors(int arg) {
        return arg * (tilesMargin + tileSize) + tilesMargin;
    }
    
    public Color getBackground(int value) {
        switch (value) {
            case 2:    
                return new Color(0xeee4da);
            case 4:    
                return new Color(0xede0c8);
            case 8:    
                return new Color(0xf2b179);
            case 16:   
                return new Color(0xf59563);
            case 32:   
                return new Color(0xf67c5f);
            case 64:   
                return new Color(0xf65e3b);
            case 128:  
                return new Color(0xedcf72);
            case 256:  
                return new Color(0xedcc61);
            case 512:  
                return new Color(0xedc850);
            case 1024: 
                return new Color(0xedc53f);
            case 2048: 
                return new Color(0xedc22e);
        }
        return new Color(0xcdc1b4);
    }
    
    public Color getForeground(int value) {
        return value < 16 ? new Color(0x776e65) :  new Color(0xf9f6f2);
    }
}
