/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg2048;

import java.util.Random;

/**
 *
 * @author trufmgajtgiof
 */
public class Game2048{
    
    //game function attributes
    private int gridSize;
    private Random r = new Random(); //random generator 
    private int[][] board; //create the array to store tile's value
    public boolean lose = false;
    public boolean win = false;
    public int score = 0; //current score
    private int highestScore = 0; //highest score
    public int flag;
    private boolean movable;
    
    //setHighestScore of the game
    public void setHighestScore(int s) {
        highestScore = s;
    }
    //getHighestScore of the game
    public int getHighestScore(){
        return highestScore;
    }
    
    //setGridSize
    public void setGridSize(int gs){
        gridSize = gs;
    }
    
    //newGame method
    public void newNormalGame() {
        score = 0;
        lose = false;
        win = false;
        setGridSize(4);
        board = new int[gridSize][gridSize];
        for (int i = 0; i < gridSize; i++) {
            for (int j = 0; j < gridSize; j++) {
                board[i][j] = 0;
            }
        }
        addTile();
        addTile();
    }

    //display method
    public int display(int row, int column) {
        return board[row][column];
    }

    //add at a random empty space
    public void addTile() {
        int range = gridSize * gridSize;    
        int choice = r.nextInt(range);
        while (!isEmpty(choice)) {
            choice = r.nextInt(range);
        }
        int row = choice / gridSize;
        int column = choice % gridSize;
        board[row][column] = 2;
    }

    //check if empty
    public boolean isEmpty(int position) {
        int row = position / gridSize;
        int column = position % gridSize;
        return board[row][column] == 0;
    }

    //check if there's no empty place left
    public boolean isFull() {
        int check = 0;
        for (int row = 0; row < gridSize; row++) {
            int column = 0;
            while (column < gridSize) {
                int position = column + row * gridSize;
                if (isEmpty(position)) {
                    check++;
                }
                column++;
            }
        }
        return (check == 0);
    }

    //moveLeft method
    public void moveLeft() {
        int tempValue;
        boolean moved = false;
        for (int startRow = 0; startRow < gridSize; startRow++) {
            int emptyCount = 1;
            for (int startColumn = 1; startColumn < gridSize; startColumn++) {
                int currentPosition = startRow * gridSize + startColumn;
                int previousPosition = currentPosition - 1;
                if (!isEmpty(currentPosition)) {
                    if (isEmpty(previousPosition)) {
                        tempValue = board[startRow][startColumn];
                        board[startRow][startColumn] = board[startRow][startColumn - emptyCount];
                        board[startRow][startColumn - emptyCount] = tempValue;
                        int currentColumn = startColumn - emptyCount;
                        int destinationColumn = currentColumn - 1;
                        if (addUpTile(startRow, currentColumn, startRow, destinationColumn))
                            emptyCount++;
                        moved = true;
                    }
                    else{
                        int destinationColumn = startColumn - 1;
                        if (addUpTile(startRow, startColumn, startRow, destinationColumn))
                            moved = true;
                    }
                } else {
                    if (isEmpty(previousPosition))
                        emptyCount++;
                }
            }
        }
        if(moved)
            addTile();
        flag = -1;
    }

    //moveRight method
    public void moveRight() {
        int tempValue;
        boolean moved = false;
        for (int startRow = 0; startRow < gridSize; startRow++) {
            int emptyCount = 1;
            for (int startColumn = gridSize-2; startColumn >= 0; startColumn--) {
                int currentPosition = startRow * gridSize + startColumn;
                int previousPosition = currentPosition + 1;
                if (!isEmpty(currentPosition)) {
                    if (isEmpty(previousPosition)) {
                        tempValue = board[startRow][startColumn];
                        board[startRow][startColumn] = board[startRow][startColumn+emptyCount];
                        board[startRow][startColumn+emptyCount] = tempValue;
                        int currentColumn = startColumn + emptyCount;
                        int destinationColumn = currentColumn + 1;
                        if (addUpTile(startRow, currentColumn, startRow, destinationColumn))
                            emptyCount++;
                        moved = true;
                    }
                    else{
                        int destinationColumn = startColumn + 1;
                        if (addUpTile(startRow, startColumn, startRow, destinationColumn))
                            moved = true;
                    }
                } else {
                    if (isEmpty(previousPosition))
                        emptyCount++;
                }
            }
        }
        if(moved)
            addTile();
        flag = -1;
    }

    //move up method
    public void moveUp() {
        int tempValue;
        boolean moved = false;
        for (int startColumn = 0; startColumn < gridSize; startColumn++) {
            int emptyCount = 1;
            for (int startRow = 1; startRow < gridSize; startRow++) {
                int currentPosition = startRow * gridSize + startColumn;
                int previousPosition = (startRow - 1) * gridSize + startColumn;
                if (!isEmpty(currentPosition)) {
                    if (isEmpty(previousPosition)) {
                        tempValue = board[startRow][startColumn];
                        board[startRow][startColumn] = board[startRow - emptyCount][startColumn];
                        board[startRow - emptyCount][startColumn] = tempValue;
                        int currentRow = startRow - emptyCount;
                        int destinationRow = currentRow - 1;
                        if (addUpTile(currentRow, startColumn, destinationRow, startColumn))
                            emptyCount++;
                        moved = true;
                    }
                    else{
                        int destinationRow = startRow - 1;
                        if(addUpTile(startRow, startColumn, destinationRow, startColumn))
                            moved = true;
                    }
                } else {
                    if (isEmpty(previousPosition))
                        emptyCount++;
                }
            }
        }
        if (moved)
            addTile();
        flag = -1;
    }

    //move down method
    public void moveDown() {
        int tempValue;
        boolean moved = false;
        for (int startColumn = 0; startColumn < gridSize; startColumn++) {
            int emptyCount = 1;
            for (int startRow = gridSize -2; startRow >= 0; startRow--) {
                int currentPosition = startRow * gridSize + startColumn;
                int previousPosition = (startRow + 1) * gridSize + startColumn;
                if (!isEmpty(currentPosition)) {
                    if (isEmpty(previousPosition)) {
                        tempValue = board[startRow][startColumn];
                        board[startRow][startColumn] = board[startRow+emptyCount][startColumn];
                        board[startRow+emptyCount][startColumn] = tempValue;
                        int currentRow = startRow + emptyCount;
                        int destinationRow = currentRow + 1;
                        if (addUpTile(currentRow, startColumn, destinationRow, startColumn))
                            emptyCount++;
                        moved = true;
                    }
                    else{
                        int destinationRow = startRow + 1;
                        if(addUpTile(startRow, startColumn, destinationRow, startColumn))
                            moved = true;
                    }
                } else {
                    if (isEmpty(previousPosition))
                        emptyCount++;
                }
            }
        }
        if(moved)
            addTile();
        flag = -1;
    }
    
    //can still move left or not
    public boolean canMoveLeft(){
        movable = false;
        for (int row = 0; row < gridSize; row++){
            for (int column = 1; column < gridSize; column++){
                if (board[row][column] == board[row][column-1])
                    movable = true;
            }
        }
        return movable;
    }
    
    //can still move right or not
    public boolean canMoveRight(){
        movable = false;
        for (int row = 0; row < gridSize; row++){
            for (int column = gridSize - 2; column >= 0; column--){
                if (board[row][column] == board[row][column+1])
                    movable = true;
            }
        }
        return movable;
    }
    
    //can still move up or not
    public boolean canMoveUp(){
        movable = false;
        for (int column = 0; column < gridSize; column++){
            for (int row = 1; row < gridSize; row++){
                if (board[row][column] == board[row-1][column])
                    movable = true;
            }
        }
        return movable;
    }
    
    //can still move up or not
    public boolean canMoveDown(){
        movable = false;
        for (int column = 0; column < gridSize; column++){
            for (int row = gridSize - 2; row >= 0; row--){
                if (board[row][column] == board[row+1][column])
                    movable = true;
            }
        }
        return movable;
    }
    
    //add 2 identical Tiles
    public boolean addUpTile(int currentRow, int currentColumn, int destinationRow, int destinationColumn){
        int destinationPosition = destinationRow * gridSize + destinationColumn;
        if (destinationRow>-1 && destinationRow < gridSize && destinationColumn>-1 && destinationColumn <gridSize){
            if (board[currentRow][currentColumn] == board[destinationRow][destinationColumn]){
                if (destinationPosition != flag){
                    board[destinationRow][destinationColumn] *= 2;
                    board[currentRow][currentColumn] = 0;
                    score += board[destinationRow][destinationColumn];
                    if (highestScore < score){
                        highestScore = score;
                    }
                    flag = destinationPosition;
                    return true;
                }
                else
                    return false;
            }
            else
                return false;
        }
        else
            return false;
    }
}