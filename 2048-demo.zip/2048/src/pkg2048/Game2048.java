/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg2048;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.event.KeyEvent;
import java.awt.event.KeyAdapter;
import java.util.ArrayList;
import java.util.Random;
import java.util.Stack;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.WindowConstants;

/**
 *
 * @author trufmgajtgiof
 */
public class Game2048 extends JPanel{
    
    private static final Color backgroundColor = new Color(0xbbada0);
    private static final String fontName = "Arial";
    private static final int tileSize = 64;
    private static final int tilesMargin = 16;
    
    private Random r = new Random();
    private int[][] board;
    public boolean lose = false;
    public boolean win = false;
    public int score = 0;
    private int highestScore = 0;

    public void setHighestScore(int s) {
        highestScore = s;
    }

    //constructor
    public Game2048() {
        setPreferredSize(new Dimension(340, 400));
        setFocusable(true);
        addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_ESCAPE) {
                    newGame();
                }
            
                if (isFull()) {
                    lose = true;
                }
                if (!win && !lose) {
                    switch (e.getKeyCode()) {
                        case KeyEvent.VK_LEFT:
                            moveLeft();
                            break;
                        case KeyEvent.VK_RIGHT:
                            moveRight();
                            break;
                        case KeyEvent.VK_DOWN:
                            moveDown();
                            break;
                        case KeyEvent.VK_UP:
                            moveUp();
                            break;
                        }
                    }
                if (!win && isFull()) {
                    lose = true;
                }
                repaint();
            }
        }
        );
        newGame();
    }
    
    @Override
    public void paint(Graphics g) {
        Stack array = new Stack();
        for (int i=3; i>=0; i--)
            for (int j=3; j>=0; j--)
                array.push(board[i][j]);
        super.paint(g);
        g.setColor(backgroundColor);
        g.fillRect(0, 0, this.getSize().width, this.getSize().height);
        for (int y = 0; y < 4; y++) {
            for (int x = 0; x < 4; x++) {
                drawTile(g, array, x, y);
            }
        }
    }
    
    private void drawTile(Graphics g2, Stack tile, int x, int y) {
        Graphics2D g = ((Graphics2D) g2);
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g.setRenderingHint(RenderingHints.KEY_STROKE_CONTROL, RenderingHints.VALUE_STROKE_NORMALIZE);
        int value = (int)(tile.pop());
        int xOffset = offsetCoors(x);
        int yOffset = offsetCoors(y);
        g.setColor(getBackground(value));
        g.fillRoundRect(xOffset, yOffset, tileSize, tileSize, 14, 14);
        g.setColor(getForeground(value));
        final int size = value < 100 ? 36 : value < 1000 ? 32 : 24;
        final Font font = new Font(fontName, Font.BOLD, size);
        g.setFont(font);

        String s = String.valueOf(value);
        final FontMetrics fm = getFontMetrics(font);

        final int w = fm.stringWidth(s);
        final int h = -(int) fm.getLineMetrics(s, g).getBaselineOffsets()[2];

        if (value != 0)
        g.drawString(s, xOffset + (tileSize - w) / 2, yOffset + tileSize - (tileSize - h) / 2 - 2);

        if (win || lose) {
            g.setColor(new Color(255, 255, 255, 30));
            g.fillRect(0, 0, getWidth(), getHeight());
            g.setColor(new Color(78, 139, 202));
            g.setFont(new Font(fontName, Font.BOLD, 48));
            if (win) {
                g.drawString("You won!", 68, 150);
            }
            if (lose) {
                g.drawString("Game over!", 50, 130);
                g.drawString("You lose!", 64, 200);
            }
            if (win || lose) {
                g.setFont(new Font(fontName, Font.PLAIN, 16));
                g.setColor(new Color(128, 128, 128, 128));
                g.drawString("Press ESC to play again", 80, getHeight() - 40);
            }
        }
        g.setFont(new Font(fontName, Font.PLAIN, 18));
        g.drawString("Score: " + highestScore, 200, 365);
    }
    
    private static int offsetCoors(int arg) {
        return arg * (tilesMargin + tileSize) + tilesMargin;
    }
    
    public Color getBackground(int value) {
        switch (value) {
            case 2:    
                return new Color(0xeee4da);
            case 4:    
                return new Color(0xede0c8);
            case 8:    
                return new Color(0xf2b179);
            case 16:   
                return new Color(0xf59563);
            case 32:   
                return new Color(0xf67c5f);
            case 64:   
                return new Color(0xf65e3b);
            case 128:  
                return new Color(0xedcf72);
            case 256:  
                return new Color(0xedcc61);
            case 512:  
                return new Color(0xedc850);
            case 1024: 
                return new Color(0xedc53f);
            case 2048: 
                return new Color(0xedc22e);
      }
      return new Color(0xcdc1b4);
    }
    
    public Color getForeground(int value) {
        return value < 16 ? new Color(0x776e65) :  new Color(0xf9f6f2);
    }

    //newGame method
    public void newGame() {
        score = 0;
        lose = false;
        win = false;
        board = new int[4][4];
        for (int i = 0; i < 4; i++) {
            for (int j = 0; j < 4; j++) {
                board[i][j] = 0;
            }
        }
        addTile();
        addTile();
    }

    //display method
    public void display() {
        for (int i = 0; i < 4; i++) {
            for (int j = 0; j < 4; j++) {
                System.out.print("" + board[i][j] + "\t");
            }
            System.out.print("\n");
        }
        System.out.println("");
    }

    //add at a random empty space
    public void addTile() {
        int choice = r.nextInt(16);
        while (!isEmpty(choice)) {
            choice = r.nextInt(16);
        }
        int row = choice / 4;
        int column = choice % 4;
        board[row][column] = 2;
    }

    //check if empty
    public boolean isEmpty(int position) {
        int row = position / 4;
        int column = position % 4;
        if (board[row][column] == 0) {
            return true;
        } else {
            return false;
        }
    }

    //check if there's no empty place left
    public boolean isFull() {
        int check = 0;
        for (int row = 0; row < 4; row++) {
            int column = 0;
            while (column < 4) {
                int position = column + row * 4;
                if (isEmpty(position)) {
                    check++;
                }
                column++;
            }
        }
        return (check == 0);
    }

    //moveLeft method
    public void moveLeft() {
        int tempValue = 0;
        boolean movable = false;
        for (int startRow = 0; startRow < 4; startRow++) {
            int emptyCount = 1;
            for (int startColumn = 1; startColumn < 4; startColumn++) {
                int currentPosition = startRow * 4 + startColumn;
                int previousPosition = currentPosition - 1;
                if (!isEmpty(currentPosition)) {
                    if (isEmpty(previousPosition)) {
                        tempValue = board[startRow][startColumn];
                        board[startRow][startColumn] = board[startRow][startColumn - emptyCount];
                        board[startRow][startColumn - emptyCount] = tempValue;
                        int currentColumn = startColumn - emptyCount;
                        int destinationColumn = currentColumn - 1;
                        if (addUpTile(startRow, currentColumn, startRow, destinationColumn))
                            emptyCount++;
                        movable = true;
                    }
                    else{
                        int destinationColumn = startColumn - 1;
                        if (addUpTile(startRow, startColumn, startRow, destinationColumn))
                            movable = true;
                    }
                } else {
                    if (isEmpty(previousPosition))
                        emptyCount++;
                }
            }
        }
        if(movable)
            addTile();        
    }

    //moveRight method
    public void moveRight() {
        int tempValue = 0;
        boolean movable = false;
        for (int startRow = 0; startRow < 4; startRow++) {
            int emptyCount = 1;
            for (int startColumn = 2; startColumn >= 0; startColumn--) {
                int currentPosition = startRow * 4 + startColumn;
                int previousPosition = currentPosition + 1;
                if (!isEmpty(currentPosition)) {
                    if (isEmpty(previousPosition)) {
                        tempValue = board[startRow][startColumn];
                        board[startRow][startColumn] = board[startRow][startColumn+emptyCount];
                        board[startRow][startColumn+emptyCount] = tempValue;
                        int currentColumn = startColumn + emptyCount;
                        int destinationColumn = currentColumn + 1;
                        if (addUpTile(startRow, currentColumn, startRow, destinationColumn))
                            emptyCount++;
                        movable = true;
                    }
                    else{
                        int destinationColumn = startColumn + 1;
                        if (addUpTile(startRow, startColumn, startRow, destinationColumn))
                            movable = true;
                    }
                } else {
                    if (isEmpty(previousPosition))
                        emptyCount++;
                }
            }
        }
        if(movable)
            addTile();
    }

    //move up method
    public void moveUp() {
        int tempValue = 0;
        boolean movable = false;
        for (int startColumn = 0; startColumn < 4; startColumn++) {
            int emptyCount = 1;
            for (int startRow = 1; startRow < 4; startRow++) {
                int currentPosition = startRow * 4 + startColumn;
                int previousPosition = (startRow - 1) * 4 + startColumn;
                if (!isEmpty(currentPosition)) {
                    if (isEmpty(previousPosition)) {
                        tempValue = board[startRow][startColumn];
                        board[startRow][startColumn] = board[startRow - emptyCount][startColumn];
                        board[startRow - emptyCount][startColumn] = tempValue;
                        int currentRow = startRow - emptyCount;
                        int destinationRow = currentRow - 1;
                        if (addUpTile(currentRow, startColumn, destinationRow, startColumn))
                            emptyCount++;
                        movable = true;
                    }
                    else{
                        int destinationRow = startRow - 1;
                        if(addUpTile(startRow, startColumn, destinationRow, startColumn))
                            movable = true;
                    }
                } else {
                    if (isEmpty(previousPosition))
                        emptyCount++;
                }
            }
        }
        if (movable)
            addTile();
    }

    //move down method
    public void moveDown() {
        int tempValue = 0;
        boolean movable = false;
        for (int startColumn = 0; startColumn < 4; startColumn++) {
            int emptyCount = 1;
            for (int startRow = 2; startRow >= 0; startRow--) {
                int currentPosition = startRow * 4 + startColumn;
                int previousPosition = (startRow + 1) * 4 + startColumn;
                if (!isEmpty(currentPosition)) {
                    if (isEmpty(previousPosition)) {
                        tempValue = board[startRow][startColumn];
                        board[startRow][startColumn] = board[startRow+emptyCount][startColumn];
                        board[startRow+emptyCount][startColumn] = tempValue;
                        int currentRow = startRow + emptyCount;
                        int destinationRow = currentRow + 1;
                        if (addUpTile(currentRow, startColumn, destinationRow, startColumn))
                            emptyCount++;
                        movable = true;
                    }
                    else{
                        int destinationRow = startRow + 1;
                        if(addUpTile(startRow, startColumn, destinationRow, startColumn))
                            movable = true;
                    }
                } else {
                    if (isEmpty(previousPosition))
                        emptyCount++;
                }
            }
        }
        if(movable)
            addTile();
    }
    
    //compare if two tiles have the same value
    public boolean addUpTile(int currentRow, int currentColumn, int destinationRow, int destinationColumn){
        if (destinationRow>-1 && destinationRow <4 && destinationColumn>-1 && destinationColumn <4){
            if (board[currentRow][currentColumn] == board[destinationRow][destinationColumn]){
                board[destinationRow][destinationColumn] *= 2;
                board[currentRow][currentColumn] = 0;
                highestScore += board[destinationRow][destinationColumn];
                return true;
            }
            else
                return false;
        }
        else
            return false;
    }

    //main
    public static void main(String[] args) {JFrame game = new JFrame();
    game.setTitle("2048 Game");
    game.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
    game.setSize(340, 400);
    game.setResizable(false);

    game.add(new Game2048());

    game.setLocationRelativeTo(null);
    game.setVisible(true);
    }
}